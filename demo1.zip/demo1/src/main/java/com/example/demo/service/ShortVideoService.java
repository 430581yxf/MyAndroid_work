package com.example.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.entity.Videos;

public interface ShortVideoService extends IService<Videos> {
}
