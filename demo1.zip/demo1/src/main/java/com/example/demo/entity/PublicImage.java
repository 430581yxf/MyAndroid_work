package com.example.demo.entity;

public class PublicImage {
    public long id;
    public long publicMessageId;
    public String content;
}
