package com.example.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.entity.Message;

public interface MessageService extends IService<Message> {
}
